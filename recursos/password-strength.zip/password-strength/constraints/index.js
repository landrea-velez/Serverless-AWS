module.exports = {
  verifyPasswordLength: require('./verifyPasswordLength'),
  verifyPasswordStrength: require('./verifyPasswordStrength'),
};